import { HttpClient } from '@angular/common/http';

import { Injectable } from '@angular/core';




@Injectable({

  providedIn: 'root'

})

export class AppService {

  loggedInUserDetails: any;

 url="http://localhost:8117"




  constructor(private htt:HttpClient) { }

  login(email:any,password:any){

    return this.htt.post(this.url+'/user/login',{

        email:email , password: password

    });




  }




  register(data:any){

   return this.htt.post(this.url+'/user/signup',data);

  }

  getUserDetailByEmail(email?: string){

    return this.htt.get(this.url+'/user/'+email);

  }




  getLoggedInUserDetails(){

    return this.loggedInUserDetails;

  }

  setLoggedInUserDetails(data: any){

    this.loggedInUserDetails = data;

  }



  url1="http://localhost:8117/admin/getTheme";

  them(){

    return this.htt.get(this.url1);

}




url2="http://localhost:8117/admin/addTheme";

addtheme(data:any){

  return this.htt.post(this.url2,data);

}




deletetheme(themeId:number){

  return this.htt.delete("http://localhost:8117/admin/deleteTheme"+`/${themeId}`);

}




updatetheme(themeId:number,data:any){

  return this.htt.put("http://localhost:8117/admin/edittheme"+`/${themeId}`,data);




}

url3="http://localhost:8117/admin/getGift";

  gift(){

    return this.htt.get(this.url3);

}

url4="http://localhost:8117/admin/addGift";

addgift(data:any){

  return this.htt.post(this.url4,data);

}




deletegift(giftId:number){

  return this.htt.delete("http://localhost:8117/admin/deleteGift"+`/${giftId}`);

}




updategift(giftId:number,data:any){

  return this.htt.put("http://localhost:8117/admin/editGift"+`/${giftId}`,data);

}


deleteorder(orderId:number){

      return this.htt.delete("http://localhost:8117/admin/deleteOrder"+`/${orderId}`);
    
    }
     order(){

            return this.htt.get("http://localhost:8117/admin/getAllOrders");
        
        }

      

        
    
    


}
