export interface product{

    giftId:number;
    giftName:string;
    giftPrice:number;
    giftDetails:number;
    quantity:undefined | number;
}