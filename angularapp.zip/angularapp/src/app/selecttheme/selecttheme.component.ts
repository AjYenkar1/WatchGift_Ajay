import { Component } from '@angular/core';
import { UserdataserviceService } from '../service/userdataservice.service';

@Component({
  selector: 'app-selecttheme',
  templateUrl: './selecttheme.component.html',
  styleUrls: ['./selecttheme.component.css']
})
export class SelectthemeComponent {
  

//     alltheme: any;
// theme:any
//     constructor(private userservice:UserdataserviceService){
  
//         userservice.them().subscribe((data: any)=>{
  
//         console.log("data",data);
  
//         this.theme=data;
  
//       });
  
//     }
//   addusertheme(data:any)

// {

//   console.warn(data);

//   this.userservice.addtheme(data).subscribe((result)=>{

//     console.warn(result)

//   })

//}

}
